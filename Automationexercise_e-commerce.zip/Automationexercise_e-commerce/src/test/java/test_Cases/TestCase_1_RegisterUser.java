package test_Cases;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestCase_1_RegisterUser {
  @Test
  public void RigisterUser() throws InterruptedException {
//	  Test Case 1: Register User
//	  1. Launch browser
	  	WebDriver driver = new ChromeDriver();
	  
//	  2. Navigate to url 'http://automationexercise.com'
	  	driver.get("http://automationexercise.com");
	  	driver.manage().window().maximize();
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  3. Verify that home page is visible successfully	  	  	
	  	WebElement home = driver.findElement(By.xpath("//a[text()=' Home']"));	  	
	  	if(home.isDisplayed())
	  	{
	  		System.out.println("Home page is visible successfully");
	  	}
	  	else {
	  		System.out.println("Home page is Not visible successfully");
	  	}	  	
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  4. Click on 'Signup / Login' button
	  	driver.findElement(By.xpath("//*[text()=' Signup / Login']")).click();
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  5. Verify 'New User Signup!' is visible
	  	String expectedText ="New User Signup!";
	  	String actualText = driver.findElement(By.xpath("//h2[text()='New User Signup!']")).getText();
	  	System.out.println(actualText);
	  	if(actualText.equals(expectedText)) {
	  		System.out.println("'New User Signup!' is visible");
	  	} else {
	  		System.out.println("'New User Signup!' is Not visible");
	  	}
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  6. Enter name and email address
	  	//Name
	  	driver.findElement(By.name("name")).sendKeys("Sunil Dh");
	  	//email
	  	driver.findElement(By.xpath("(//input[@name='email'])[2]")).sendKeys("Sunildh123@gmail.com");
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  7. Click 'Signup' button
	  	driver.findElement(By.xpath("//button[text()='Signup']")).click();
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  8. Verify that 'ENTER ACCOUNT INFORMATION' is visible
	  	WebElement actText = driver.findElement(By.xpath("//b[text()='Enter Account Information']"));
	  	System.out.println(actText);
	  	if(actText.isDisplayed()) {
	  		System.out.println("'ENTER ACCOUNT INFORMATION' is visible");
	  	} else {
	  		System.out.println("'ENTER ACCOUNT INFORMATION' is not visible");
	  	}
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  9. Fill details: Title, Name, Email, Password, Date of birth
	  	//Click Title 
	  	driver.findElement(By.id("id_gender1")).click();
	  	
	  	//Password 
	  	driver.findElement(By.id("password")).sendKeys("Sunil@1234");
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
	  	//Date of birth
	  	//Day
	  		Select day = new Select(driver.findElement(By.id("days")));
	  		day.selectByValue("31");
	  	//month
	  		Select month = new Select(driver.findElement(By.id("months")));
	  		month.selectByValue("3");
	  	//Year 
	  		Select year = new Select(driver.findElement(By.id("years")));
	  		year.selectByValue("1997");
	  		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  10. Select checkbox 'Sign up for our newsletter!'
	  	driver.findElement(By.name("newsletter")).click();
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));	
	  		
//	  11. Select checkbox 'Receive special offers from our partners!'
	  	driver.findElement(By.id("optin")).click();
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  12. Fill details: First name, Last name, Company, Address, Address2, Country, State, City, Zipcode, Mobile Number
	  	//First name
	  		driver.findElement(By.id("first_name")).sendKeys("Sunil");
	  	//Last name
	  		driver.findElement(By.id("last_name")).sendKeys("Dh");
	  	//Company
	  		driver.findElement(By.name("company")).sendKeys("Royal Auto");
	  	//Address
	  		driver.findElement(By.name("address1")).sendKeys("Gat no. 17, Awale Chouk, Near zol karkhana, Kabnoor.");
	  	//Address2
	  		driver.findElement(By.name("address2")).sendKeys("Ichalkaranji");
	  		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	//Country
	  		Select country = new Select(driver.findElement(By.id("country")));
	  		country.selectByVisibleText("India");
	  	//State 
	  		driver.findElement(By.id("state")).sendKeys("Maharashtra");
	  	//City 
	  		driver.findElement(By.id("city")).sendKeys("kabnur");
	  		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	//Zipcode
	  		driver.findElement(By.id("zipcode")).sendKeys("416115");
	  	//Mobile Number
	  		driver.findElement(By.id("mobile_number")).sendKeys("9156415903");
	  		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  		
//	  13. Click 'Create Account button'
	  	driver.findElement(By.xpath("//button[text()='Create Account']")).click();
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  14. Verify that 'ACCOUNT CREATED!' is visible
	  	WebElement accountCreate = driver.findElement(By.xpath("//b[text()='Account Created!']"));
	  	if(accountCreate.isDisplayed()) {
	  		System.out.println("'ACCOUNT CREATED!' is visible");
	  	} else {
	  		System.out.println("'ACCOUNT CREATED!' is not visible");
	  	}
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  		  	
//	  15. Click 'Continue' button
	  	driver.findElement(By.linkText("Continue")).click();
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  16. Verify that 'Logged in as username' is visible
	  	String expText1 = "Logged in as Sunil Dh";
	  	String actText1 = driver.findElement(By.xpath("//a[text()=' Logged in as ']")).getText();
	  	Assert.assertEquals(actText1, expText1);
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
/*	  17. Click 'Delete Account' button		
		driver.findElement(By.xpath("//a[text()=' Delete Account']")).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 
//	  18. Verify that 'ACCOUNT DELETED!' is visible and click 'Continue' button
	  	String expText2 = "Account Deleted!";
	  	String actText2 = driver.findElement(By.xpath("//b[text()='Account Deleted!']")).getText();
	  	if(actText2.equals(expText2)) {
	  		System.out.println("'ACCOUNT Deleted!' is visible");
	  	} else {
	  		System.out.println("'ACCOUNT Deleted!' is not visible");
	  	}
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
	  	//Click 'Continue button'
	  	driver.findElement(By.linkText("Continue")).click();
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); */
	  	
	  	driver.close();	  		  
  }
}
