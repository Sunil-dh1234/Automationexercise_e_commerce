package test_Cases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestCase_7_VerifyTestCasesPage {
  @Test
  public void f() throws InterruptedException {
//	  Test Case 7: Verify Test Cases Page
//	  1. Launch browser
	     WebDriver driver = new ChromeDriver();
	     
//	  2. Navigate to url 'http://automationexercise.com'
	     driver.navigate().to("http://automationexercise.com");
	     driver.manage().window().maximize();
	     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	     
//	  3. Verify that home page is visible successfully
	     WebElement home = driver.findElement(By.xpath("//a[text()=' Home']"));	  	
	     if(home.isDisplayed()) {
		 	System.out.println("Home page is visible successfully");
		 } else {
		    System.out.println("Home page is Not visible successfully");
		 }	  	
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	     	     
//	  4. Click on 'Test Cases' button
	     driver.findElement(By.xpath("//a[text()=' Test Cases']")).click();
	     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	     
//	  5. Verify user is navigated to test cases page successfully
	     String expTestpage = "TEST CASES";
	     String actTestpage = driver.findElement(By.xpath("//b[text()='Test Cases']")).getText();
	     if(actTestpage.equals(expTestpage)) {
	    	 System.out.println("Verify Test case page visible");
	     } else {
	    	 System.out.println("Test case page not visible");	    	 
	     }
	     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	     
	     driver.quit();	  
  }
}
