package test_Cases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestCase_4_LogoutUser {
  @Test
  public void f() throws InterruptedException {
//	  Test Case 4: Logout User
//	  1. Launch browser
	  	 WebDriver driver = new ChromeDriver();
	  	 
//	  2. Navigate to url 'http://automationexercise.com'
	  	 driver.get("http://automationexercise.com");
	  	 driver.manage().window().maximize();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  3. Verify that home page is visible successfully
	  	 WebElement home = driver.findElement(By.xpath("//a[text()=' Home']"));	  	
	  	 if(home.isDisplayed())
	  	 {
	  		System.out.println("Home page is visible successfully");
	  	 }
	  	 else {
	  		System.out.println("Home page is Not visible successfully");
	  	 }	  	
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	 
//	  4. Click on 'Signup / Login' button
	  	 driver.findElement(By.xpath("//*[text()=' Signup / Login']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  
//	  5. Verify 'Login to your account' is visible
	  	 WebElement login = driver.findElement(By.xpath("//h2[text()='Login to your account']"));
	  	 if(login.isDisplayed()) {
	  		 System.out.println("'Verify Login to your account' is visible successully");
	  	 } else {
	  		 System.out.println("Verify Login to your account is not visible");
	  	 }
	  	 
//	  6. Enter correct email address and password
	  	 //Name
		 driver.findElement(By.xpath("(//input[@name='email'])[1]")).sendKeys("Sunildh123@gmail.com");
		 //email
		 driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Sunil@1234");
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  	
//	  7. Click 'login' button
		 driver.findElement(By.xpath("//button[text()='Login']")).click();
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 
//	  8. Verify that 'Logged in as username' is visible
		 WebElement userName = driver.findElement(By.xpath("//a[text()=' Logged in as ']"));
		 if(userName.isDisplayed()) {
			 System.out.println("Logged in as Sunil Dh is visible successfully");
		 } else {
			 System.out.println("Not logged successufully");
		 }
		 
//	  9. Click 'Logout' button
		 driver.findElement(By.xpath("//a[text()=' Logout']")).click();
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 
//	  10. Verify that user is navigated to login page
		 WebElement loginPage = driver.findElement(By.xpath("//h2[text()='Login to your account']"));
		 if(loginPage.isDisplayed()) {
			 System.out.println("User navigated back to login page after logout.");
		 } else {
			 System.out.println("Log in page is not visible");	 
		 }		 
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 
		 driver.close();
  }
}
