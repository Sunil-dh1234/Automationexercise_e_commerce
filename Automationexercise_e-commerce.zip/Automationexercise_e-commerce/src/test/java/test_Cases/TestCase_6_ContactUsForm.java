package test_Cases;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class TestCase_6_ContactUsForm {
	 WebDriverWait wait;
  @Test
  public void f() throws InterruptedException, AWTException {
	  
//	  Test Case 6: Contact Us Form
//	  1. Launch browser
	  	 WebDriver driver = new ChromeDriver();
	  	 
//	  2. Navigate to url 'http://automationexercise.com'
	  	 driver.get("http://automationexercise.com");
	  	 driver.manage().window().maximize();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  
//	  3. Verify that home page is visible successfully
	  	 WebElement home = driver.findElement(By.xpath("//a[text()=' Home']"));	  	 
	  	 if(home.isDisplayed()) {
	  		 System.out.println("home page is visible successfully");
	  	 } else
	  	 {
	  		 System.out.println("home page is not visible successfully");
	  	 }
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  4. Click on 'Contact Us' button
	  	 driver.findElement(By.xpath("//a[text()=' Contact us']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  
//	  5. Verify 'GET IN TOUCH' is visible			 
		 WebElement getInTouch = driver.findElement(By.xpath("//h2[text()='Get In Touch']"));
		 System.out.println(getInTouch); 
		 if(getInTouch.isDisplayed()){
			 System.out.println("Verify Text:'GET IN TOUCH is visible'");
		 }  else {
			 System.out.println("Verify Text: GET IN TOUCH is Not visible");
		 }
	  	 
//	  6. Enter name, email, subject and message
	  	 //name
	  	   driver.findElement(By.name("name")).sendKeys("Sunil Dh");
	  	 //email
	  	   driver.findElement(By.name("email")).sendKeys("Sunildh123@gmail.com");
	  	 //subject
	  	   driver.findElement(By.name("subject")).sendKeys("Verify Testing");
	  	 //message
	  	   driver.findElement(By.id("message")).sendKeys("If you have any suggestion areas or improvements, do let us know. We will definitely work on it.\n"
	  	   		+ "\n"
	  	   		+ "\n"
	  	   		+ "Thank you");
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  7. Upload file	  	 
	  	 WebElement uploadFile =driver.findElement(By.xpath("//input[@name='upload_file']"));
	  	 uploadFile.sendKeys("E:\\Swapnil Intellipat\\Roles and Responsibilities.rtf");
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  8. Click 'Submit' button
	  	 driver.findElement(By.name("submit")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  9. Click OK button
	  	 driver.switchTo().alert().accept();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  10. Verify success message 'Success! Your details have been submitted successfully.' is visible
	  	 String expSuccessText = "Success! Your details have been submitted successfully.";	
	  	 String actSuccessText = driver.findElement(By.xpath("(//div[contains(text(),'Success! Your')])[1]")).getText();
	  	 if(actSuccessText.equals(expSuccessText)) {
	  		 System.out.println("Massage: Success! Your details have been submitted successfully");
	  	 } else {
	  		 System.out.println("Massage: Error! Your details have been not submitted successfully");
	  	 }	  	 
	  	 
//	  11. Click 'Home' button and verify that landed to home page successfully
//	  	 WebElement home = driver.findElement(By.xpath("//a[text()=' Home']"));
	  	 home.click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
	  	 //Verify Home
	  	 if(home.isDisplayed()) {
	  		 System.out.println("Home page landed successfully ");
	  	 } else {
	  		 System.out.println("Home page not landed successfully");
	  	 }
	  	 
	  	 driver.close();
  	}
}
