package test_Cases;

import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestCase_9_SearchProduct {
  @Test
  public void f() throws InterruptedException {
//	  Test Case 9: Search Product
//	  1. Launch browser
	  	 WebDriver driver = new ChromeDriver();
	  	 
//	  2. Navigate to url 'http://automationexercise.com'
	  	 driver.navigate().to("http://automationexercise.com");
	  	 driver.manage().window().maximize();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  3. Verify that home page is visible successfully
	  	 WebElement homePage = driver.findElement(By.xpath("//a[text()=' Home']"));
	  	 if(homePage.isDisplayed()) {
	  		 System.out.println("Home page is visible successfully");
	  	 } else {
	  		 System.out.println("Faild to open Home page ");
	  	 } 	  		 
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  4. Click on 'Products' button
	  	 driver.findElement(By.xpath("//a[text()=' Products']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  5. Verify user is navigated to ALL PRODUCTS page successfully
	  	 WebElement products = driver.findElement(By.xpath("//h2[text()='All Products']"));
	  	 if(products.isDisplayed()) {
	  		 System.out.println("All Prouducts page visible successfully");
	  	 } else {
	  		 System.out.println("Failed to All prouduct page visible");
	  	 }
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  6. Enter product name in search input and click search button
	  	 WebElement search = driver.findElement(By.xpath("//input[@name='search']"));
	  	 search.sendKeys("Tshirts");
	  	 driver.findElement(By.id("submit_search")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 	  	 
//	  7. Verify 'SEARCHED PRODUCTS' is visible
	  	 WebElement searchProduct = driver.findElement(By.xpath("//h2[text()='Searched Products']"));
	  	 if(searchProduct.isDisplayed()) {
	  		 System.out.println("Searched Products are visible");
	  	 }
	  	 
//	  8. Verify all the products related to search are visible
	  	 List<WebElement> allProducts = driver.findElements(By.xpath("//div[@class='productinfo text-center']"));
	  	 if(allProducts.size()>0) {
	  		 System.out.println("All Products releted to Search are visible. Total Products found :" + allProducts.size());
	  	 } else {
	  		 System.out.println("No Products found for search keyword");
	  	 } 
	  	 
	  	 driver.quit();	  	 
  }
} 
