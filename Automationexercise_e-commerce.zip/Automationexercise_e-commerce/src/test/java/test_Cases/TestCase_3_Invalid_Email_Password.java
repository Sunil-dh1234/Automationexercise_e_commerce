package test_Cases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class TestCase_3_Invalid_Email_Password {
  @Test
  public void f() throws InterruptedException {
//	  Test Case 3: Login User with incorrect email and password
//	  1. Launch browser
	  	 WebDriver driver = new EdgeDriver();
	  	 
//	  2. Navigate to url 'http://automationexercise.com'
	  	 driver.get("http://automationexercise.com");
	  	 driver.manage().window().maximize();
	  	 Thread.sleep(3000);
	  	 
//	  3. Verify that home page is visible successfully
	  	WebElement home = driver.findElement(By.xpath("//a[text()=' Home']"));	  	
	  	if(home.isDisplayed())
	  	{
	  		System.out.println("Home page is visible successfully");
	  	}
	  	else {
	  		System.out.println("Home page is Not visible successfully");
	  	}	  	
	  	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  
//	  4. Click on 'Signup / Login' button
		 driver.findElement(By.xpath("//*[text()=' Signup / Login']")).click();
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  5. Verify 'Login to your account' is visible
		 String expectedText = "Login to your account";
	  	 String actualText = driver.findElement(By.xpath("//h2[text()='Login to your account']")).getText();
		 if(actualText.equals(expectedText))
		 {
		 	System.out.println("Login to your account' is visible");
		 }
		 else {
		 	System.out.println("Login to your account' is not visible");
		 }	  	
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 	  
//	  6. Enter incorrect email address and password
		 driver.findElement(By.name("email")).sendKeys("Sunildh1235@gmail.com");
		 driver.findElement(By.name("password")).sendKeys("Sunil@12345");
		 Thread.sleep(2000);
		 
//	  7. Click 'login' button
		 driver.findElement(By.xpath("//button[text()='Login']")).click();
		 Thread.sleep(2000);
		 
//	  8. Verify error 'Your email or password is incorrect!' is visible
		 String expErrorMsg = "Your email or password is incorrect!"; 
		 String actErrorMsg =driver.findElement(By.xpath("//p[contains(text(),'password is incorrect!')]")).getText();
		 if(actErrorMsg.equals(expErrorMsg)) {
			 System.out.println("Verify Valid Error Msg");
		 } else
		 {
			 System.out.println("Verify invalid Error Msg");
		 }		 		 
		 driver.close();
  }
}
