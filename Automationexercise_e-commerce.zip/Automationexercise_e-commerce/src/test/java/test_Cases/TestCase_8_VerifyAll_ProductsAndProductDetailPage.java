package test_Cases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestCase_8_VerifyAll_ProductsAndProductDetailPage {
  @Test
  public void f() throws InterruptedException {
//	  Test Case 8: Verify All Products and product detail page
//	  1. Launch browser
	  	 WebDriver driver = new ChromeDriver();
	  	 
//	  2. Navigate to url 'http://automationexercise.com'
	  	 driver.get("http://automationexercise.com");
	  	 driver.manage().window().maximize();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  3. Verify that home page is visible successfully
	  	 WebElement homepage = driver.findElement(By.xpath("//a[text()=' Home']"));
	  	 if(homepage.isDisplayed()) {
	  		 System.out.println("Home page is visible successfully");
	  	 }
	  	 
//	  4. Click on 'Products' button
	  	 driver.findElement(By.xpath("//a[text()=' Products']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  5. Verify user is navigated to ALL PRODUCTS page successfully
	  	 String expText = "ALL PRODUCTS";
	  	 String actText = driver.findElement(By.xpath("//h2[text()='All Products']")).getText();
	  	 if(actText.equals(expText)) {
	  		 System.out.println("All Products page is visible successfully");
	  	 } else {
	  		 System.out.println("All Products page is not visible");
	  	 }
	  	 
//	  6. The products list is visible
	  	 WebElement productList = driver.findElement(By.className("features_items"));
	  	 if(productList.isDisplayed()) {
	  		 System.out.println("Product List is visible");
	  	 }
	  	 
//	  7. Click on 'View Product' of first product
	  	 driver.findElement(By.xpath("(//a[text()='View Product'])[1]")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  8. User is landed to product detail page
	  	 WebElement productDetails = driver.findElement(By.className("product-details"));
	  	 if(productDetails.isDisplayed()) {
	  		 System.out.println("User is landed to Product detail page");
	  	 }
	  	 
//	  9. Verify that detail detail is visible: product name, category, price, availability, condition, brand
	  	 WebElement productname = driver.findElement(By.xpath("//h2[text()='Blue Top']"));
	  	 WebElement category = driver.findElement(By.xpath("//p[text()='Category: Women > Tops']"));
	  	 WebElement price = driver.findElement(By.xpath("//span[text()='Rs. 500']")); 
	  	 WebElement availability = driver.findElement(By.xpath("//p[text()=' In Stock']"));  
	  	 WebElement condition = driver.findElement(By.xpath("//p[text()=' New']"));
	  	 WebElement brand = driver.findElement(By.xpath("//p[text()=' Polo']"));
	  	 
	  	 if(productname.isDisplayed() & category.isDisplayed() & price.isDisplayed() & availability.isDisplayed() & condition.isDisplayed() & 
	  			 brand.isDisplayed()) {
	  		 System.out.println("Product Details are visible successfully");
	  	 }
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 driver.close();
  }
}
