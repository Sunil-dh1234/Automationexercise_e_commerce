package test_Cases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestCase_5_RegisterUserwithExistingEmail {
  @Test
  public void f() throws InterruptedException {
//	  Test Case 5: Register User with existing email
//	  1. Launch browser
	  	 WebDriver driver = new ChromeDriver();
	  	 
//	  2. Navigate to url 'http://automationexercise.com'
	  	 driver.get("http://automationexercise.com");
	  	 driver.manage().window().maximize();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  3. Verify that home page is visible successfully
	  	 WebElement home = driver.findElement(By.xpath("//a[text()=' Home']"));	  	
	  	 if(home.isDisplayed()) {
	  		System.out.println("Home page is visible successfully");
	  	 }
	  	 else {
	  		System.out.println("Home page is Not visible successfully");
	  	 }	  	
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  4. Click on 'Signup / Login' button
	  	 driver.findElement(By.xpath("//a[contains(text(),' Signup')]")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  5. Verify 'New User Signup!' is visible
	  	 String expText = "New User Signup!";
	  	 String actText = driver.findElement(By.xpath("//h2[text()='New User Signup!']")).getText();
	  	 Assert.assertEquals(actText, expText);
	  	 
//	  6. Enter name and already registered email address
	  	 driver.findElement(By.name("name")).sendKeys("Sunil Dh");
	  	 driver.findElement(By.xpath("(//input[@name='email'])[2]")).sendKeys("Sunildh123@gmail.com");
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  7. Click 'Signup' button
	  	 driver.findElement(By.xpath("//button[text()='Signup']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  8. Verify error 'Email Address already exist!' is visible
	  	 String expErrorMsg = "Email Address already exist!";
	  	 String actErrorMsg = driver.findElement(By.xpath("//p[contains(text(),'Email Address')]")).getText();
	  	 Assert.assertEquals(actErrorMsg, expErrorMsg);
	  	 
	  	 driver.close();
  }
}
