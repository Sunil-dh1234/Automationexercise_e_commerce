package test_Cases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;


public class TestCase_11_AddToCart {
  @Test
  public void f() throws InterruptedException {	  	  
//	  Test Case 11: Veriy add to cart and purchase the product
//	  1. Launch browser.
	  	 WebDriver driver = new ChromeDriver();
	  	 
//	  2. Navigate to URL http://automationexercise.com.
	  	 driver.navigate().to("http://automationexercise.com.");
	  	 driver.manage().window().maximize();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  3. Verify homepage is loaded successfully.
	  	 WebElement homePage = driver.findElement(By.xpath("//a[text()=' Home']"));
	  	 if(homePage.isDisplayed()) {
	  		 System.out.println("Home page is visible successfully");
	  	 } else {
	  		 System.out.println("Home page is not visible");
	  	 }
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  4. Click on 'Products' button.
	  	 driver.findElement(By.xpath("//a[text()=' Products']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	
//	  5. Hover over any product and click 'Add to cart'.
	  	 Actions a = new Actions(driver);
	  	 WebElement addToCart = driver.findElement(By.xpath("(//a[text()='Add to cart'])[3]"));
	  	 a.moveToElement(addToCart).build().perform();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 driver.findElement(By.xpath("(//a[text()='Add to cart'])[4]")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
  	 
	  	 
//	  6. Click 'View Cart' button.
	  	 driver.findElement(By.xpath("//u[text()='View Cart']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  7. Verify that product is added to cart.
	  	 WebElement cart = driver.findElement(By.xpath("//table[@id='cart_info_table']"));
	  	 if(cart.isDisplayed()) {
	  		 System.out.println("Verify = Product is added to cart successfully. "
	  		 + "Prouduct Details :" + cart.getText());
	  	 } else {
	  		 System.out.println("Prouduct is not added to cart");
	  	 }
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  8. Click Proceed To Checkout button.
	  	 driver.findElement(By.xpath("//a[text()='Proceed To Checkout']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  9. Register/Login if not already logged in.
	  	 driver.findElement(By.xpath("//u[text()='Register / Login']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  10 Login to your account 
	  	 driver.findElement(By.xpath("(//input[@name='email'])[1]")).sendKeys("Sunildh123@gmail.com");
	  	 driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Sunil@1234");
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  11 Click login
	  	 driver.findElement(By.xpath("//button[text()='Login']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  12 Click to cart 
	  	 driver.findElement(By.xpath("//a[text()=' Cart']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  13 Click Proceed To Checkout button.
	  	 driver.findElement(By.xpath("//a[text()='Proceed To Checkout']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));  	 
	  	 
//	  14 Verify Address Details and Review Your Order.
	  	  //Address Details
	  	  WebElement addressDetails = driver.findElement(By.xpath("//h2[text()='Address Details']"));
	  	  if(addressDetails.isDisplayed()) {
	  		  System.out.println("Verify Address Details is visible");
	  	  } else {
	  		  System.out.println("Address Details not visible");	  		  
	  	  }	  	  
	  	
//	  15 Review Your Order
	  	  WebElement yourOrder = driver.findElement(By.xpath("//h2[text()='Review Your Order']"));
	  	  if(yourOrder.isDisplayed()) {
	  		  System.out.println("Review Your Order is visible succesfully");
	  	  } else {
	  		  System.out.println("Review your Order is not visible");
	  	  }
	  	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	  
//	  13. Enter a comment in the comment text area.
	  	  driver.findElement(By.name("message")).sendKeys("Product Deliver between 9 pm to 10 pm.");	  	  
	  	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	  
//	  14. Click Place Order button.
	  	  driver.findElement(By.xpath("//a[text()='Place Order']")).click();
	  	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	  
//	  15. Enter payment details: Name on Card, Card Number, CVC, Expiry.
	  	  //Name on Card
	  	    driver.findElement(By.name("name_on_card")).sendKeys("Sunil Dh");	  	 
	  	  //Card Number
	  	    driver.findElement(By.name("card_number")).sendKeys("12344");
	  	  //CVC
	  	    driver.findElement(By.name("cvc")).sendKeys("132");
	  	  //Expiry
	  	    driver.findElement(By.name("expiry_month")).sendKeys("09");
	  	  //Year  
	  	    driver.findElement(By.name("expiry_year")).sendKeys("2031");
	  	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	    
//	  16. Click on Pay on confirm Order
	  	  driver.findElement(By.id("submit")).click();
	  	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	    
//	  17. Verify success message "Your order has been placed successfully!".
	  	  WebElement orderMsg = driver.findElement(By.xpath("//p[contains(text(),'Congratulations! Your')]"));
	  	  if(orderMsg.isDisplayed()) {
	  		  System.out.println("Message = 'Congratulations! Your order has been confirmed!'");
	  	  } else {
	  		  System.out.println("Message = 'Your order is not palaced'");
	  	  }
	  	  
	  	  driver.close();	  
  }
}
