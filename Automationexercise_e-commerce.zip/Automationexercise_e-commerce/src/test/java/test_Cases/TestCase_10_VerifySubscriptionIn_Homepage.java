package test_Cases;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class TestCase_10_VerifySubscriptionIn_Homepage {
  @Test
  public void f() throws InterruptedException {  
//	  Test Case 10: Verify Subscription in home page
//	  1. Launch browser
	  	 WebDriver driver = new ChromeDriver();
	  	 
//	  2. Navigate to url 'http://automationexercise.com'
	  	 driver.navigate().to("http://automationexercise.com");
	  	 driver.manage().window().maximize();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  3. Verify that home page is visible successfully
	  	 WebElement homePage = driver.findElement(By.xpath("//a[text()=' Home']"));
	  	 if(homePage.isDisplayed()) {
	  		 System.out.println("Home Page is visible successfully");
	  	 } else {
	  		 System.out.println("Failed to Home page is visible ");
	  	 }
	  	 
//	  4. Scroll down to footer
	  	 homePage.sendKeys(Keys.PAGE_DOWN);
	   	 homePage.sendKeys(Keys.END);
	   	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	   	 
//	  5. Verify text 'SUBSCRIPTION'
	  	 WebElement subscription = driver.findElement(By.xpath("//h2[text()='Subscription']"));
	  	 if(subscription.isDisplayed()) {
	  		 System.out.println("SUBSCRIPTION is visible successfully");
	  	 } else {
	  		 System.out.println("SUBSCRIPTION is not visible");
	  	 }	  		 
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));  	 
	  	 
//	  6. Enter email address in input and click arrow button
	  	 driver.findElement(By.xpath("//input[@id='susbscribe_email']")).sendKeys("Sunildh123@gmail.com");
	  	 driver.findElement(By.xpath("//i[contains(@class,'fa fa-ar')]")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 	  	 
//	  7. Verify success message 'You have been successfully subscribed!' is visible
	  	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	  	 WebElement successMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'successfully subscribed!')]")));
	  	 if(successMsg.isDisplayed()) {
	  		 System.out.println("You have been successfully subscribed!' is visible (Text):" + successMsg.getText());
	  	 } else { 
	  		 System.out.println("You have been successfully subscribed!' is not visible ");
	  	 }
	  	 driver.close();
  }
}
