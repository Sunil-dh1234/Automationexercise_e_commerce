package test_Cases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TestCase_2_LoginUserwithCorrectEmailandPassword {
  @Test
  public void f() throws InterruptedException {
//	  Test Case 2: Login User with correct email and password
//	  1. Launch browser
	  	 WebDriver driver = new FirefoxDriver();
	  	 
//	  2. Navigate to url 'http://automationexercise.com'
	  	 driver.get("http://automationexercise.com");
	  	 driver.manage().window().maximize();
	  	 Thread.sleep(2000);
	  	 
//	  3. Verify that home page is visible successfully
	  	 String expectedhomeText = " Home";
	  	 String actualHomeText = driver.findElement(By.xpath("//a[text()=' Home']")).getText();
	  	 if(actualHomeText.equals(expectedhomeText))
	  	 {
	  		System.out.println("Home page is visible successfully");
	  	 }
	  	 else {
	  		System.out.println("Home page is visible unsuccessfully");
	  	 }
	  	 Thread.sleep(2000);
	  	 
//	  4. Click on 'Signup / Login' button
	  	 driver.findElement(By.xpath("//*[text()=' Signup / Login']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  	 
//	  5. Verify 'Login to your account' is visible
	  	 String expText = "Login to your account";
	  	 String actText = driver.findElement(By.xpath("//h2[text()='Login to your account']")).getText();
	  	 if(actText.equals(expText)) {
	  		 System.out.println("Login to your account is visible");
	  	 } else
	  	 {
	  		 System.out.println("Login to your account is not visible");
	  	 }
	  	 Thread.sleep(2000);
	  	 
//	  6. Enter correct email address and password
	  	 driver.findElement(By.name("email")).sendKeys("Sunildh123@gmail.com");
	  	 driver.findElement(By.name("password")).sendKeys("Sunil@1234");
	  	 Thread.sleep(2000);
	  	 
	  
//	  7. Click 'login' button
	  	 driver.findElement(By.xpath("//button[text()='Login']")).click();
	  	 Thread.sleep(2000);
	  	 
//	  8. Verify that 'Logged in as username' is visible
	  	 String expText1 = "Logged in as Sunil Dh";
	  	 String actText1 = driver.findElement(By.xpath("//a[text()=' Logged in as ']")).getText();
	  	 System.out.println("Username :" + actText);
	  	 if(actText1.equals(expText1)) {
	  		 System.out.println("Logged in as username' is visible");
	  	 } else
	  	 {
	  		 System.out.println("Logged in as username' is not visible");
	  	 }
	  	 
//	  9. Click 'Delete Account' button
	  	 driver.findElement(By.xpath("//a[text()=' Delete Account']")).click();
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  		  	 
//	  10. Verify that 'ACCOUNT DELETED!' is visible
	  	 String expText2 = "ACCOUNT DELETED!";
	  	 String actText2 = driver.findElement(By.xpath("//b[text()='Account Deleted!']")).getText();
	  	 if(actText2.equals(expText2)) {
	  		System.out.println("'ACCOUNT Deleted!' is visible");
	  	 } else {
	  		System.out.println("'ACCOUNT Deleted!' is not visible");
	  	 }
	  	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));	  	 
	  	 
	  	 driver.close();
  }
}



